/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SIBUSISO
 */
public class LogInDetailsServlet extends HttpServlet {

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //get saved log in details
        String savedUserName = getServletContext().getInitParameter("user_name");
        String savedPassword = getServletContext().getInitParameter("password");
        
        //getlog in details from user
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        
        //setthe attributes to pass to jsp
        String message  ;
        String adminEmail = getServletContext().getInitParameter("admin_email");
        //test if log in details match
        if(savedUserName.equals(username) && savedPassword.equals(password)){
            message = "User details matched\nWelcome to our system";
        }else{
            message = "User details could not match,please contact admin ot this email:\n" + adminEmail;
        }
        
        request.setAttribute("outcome", message);
        
        
        
        System.out.println("Saved username is: " + savedUserName);
        System.out.println("Saved password is: " + savedPassword);
        
        RequestDispatcher disp = request.getRequestDispatcher("outcomejsp.jsp");
        disp.forward(request, response);
        
    }

}
